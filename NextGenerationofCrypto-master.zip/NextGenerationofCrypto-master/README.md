# NextGenerationofCrypto
current project is to review Next Generation crypto
we have decided to evaluate Elliptic Light weight crypto (ELLI) ISO/IEC standard  created by NIST
our Elli method evaluation will lays down on RFID encryption method which evaluating the exchange of the RFID private key to RDFID reader of the private key and the methodology is using Elliptic curve method

To evaluate this method we write few lines of code to confirm the RDFID private key exchange from initiater device to RDFID reader private key from a remote device via their response to the initiator 
to achieve as mentioned on line above will have to import following librairy modules: urandom (32), scalarmult, scalarmult_base, and binascii
